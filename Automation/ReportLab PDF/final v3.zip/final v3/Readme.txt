1-(input) json files in json folder.
2- Output goes to pdf folder
3- put input json and output pdf filename in "main.py"